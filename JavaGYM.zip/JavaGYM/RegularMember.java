/**
 * REGULAR MEMBER CLASS
 * 
 * Extends GymMember to provide basic membership features including:
 * - Tiered membership plans (Basic/Standard/Deluxe)
 * - Attendance-based upgrade eligibility
 * - Referral tracking
 * 
 * @author Selina Singh
 * @version 16 May 2025
 */
public class RegularMember extends GymMember {
    /* Regular Membership Attributes */
    private final int attendanceLimit = 30;     // Visits needed for upgrade eligibility
    private boolean isEligibleForUpgrade;      // Upgrade qualification status
    private String removalReason;              // Reason for membership termination
    private String referralSource;             // How member was referred
    private String plan;                       // Current membership tier
    private double price;                      // Current membership price

    /**
     * CONSTRUCTOR: RegularMember
     * Initializes a regular member with basic features
     * 
     * @param id Unique member identifier
     * @param name Full name of member
     * @param location Residential address
     * @param phone Contact number
     * @param email Email address
     * @param gender Gender identification
     * @param DOB Date of birth
     * @param membershipStartDate Membership commencement date
     * @param referralSource How member was referred to gym
     */
    public RegularMember(int id, String name, String location, String phone, String email, String gender,
                        String DOB, String membershipStartDate, String referralSource) {
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.isEligibleForUpgrade = false;  // Not eligible initially
        this.referralSource = referralSource;
        this.removalReason = "";           // No removal reason initially
        this.plan = "basic";               // Default to basic plan
        this.price = 6500;                 // Basic plan price
    }

    /* ACCESSOR METHODS */
    
    /** @return Attendance limit for upgrades */
    public int getAttendanceLimit() { return attendanceLimit; }
    
    /** @return Upgrade eligibility status */
    public boolean isEligibleForUpgrade() { return isEligibleForUpgrade; }
    
    /** @return Reason for membership termination */
    public String getRemovalReason() { return removalReason; }
    
    /** @return Source of member referral */
    public String getReferralSource() { return referralSource; }
    
    /** @return Current membership plan */
    public String getPlan() { return plan; }
    
    /** @return Current membership price */
    public double getPrice() { return price; }

    /**
     * Marks regular member attendance
     * Awards loyalty points and checks upgrade eligibility
     */
    @Override
    public void markAttendance() {
        if (!isActiveStatus()) {
            System.out.println("Cannot mark attendance. Membership is inactive.");
            return;
        }
        attendance++;
        loyaltyPoints += 5;  // Award 5 points per visit
        if (attendance >= attendanceLimit) {
            isEligibleForUpgrade = true;
        }
        System.out.println("Attendance marked for member " + getId() + 
                         ". Total attendance: " + attendance);
    }

    /**
     * Gets price for specified membership plan
     * @param plan The plan to check (basic/standard/deluxe)
     * @return Plan price or -1 for invalid plans
     */
    public double getPlanPrice(String plan) {
        switch (plan.toLowerCase()) {
            case "basic": return 6500;
            case "standard": return 12500;
            case "deluxe": return 18500;
            default: return -1;  // Invalid plan indicator
        }
    }

    /**
     * Upgrades membership plan if eligible
     * @param newPlan The desired plan (basic/standard/deluxe)
     * @return Upgrade status message
     */
    public String upgradePlan(String newPlan) {
        if (!isEligibleForUpgrade) {
            return "You are not eligible to upgrade. Attendance limit not reached.";
        }
        if (this.plan.equalsIgnoreCase(newPlan)) {
            return "You are already subscribed to the " + newPlan + " plan.";
        }
        double newPrice = getPlanPrice(newPlan);
        if (newPrice == -1) {
            return "Invalid plan selected.";
        }
        this.plan = newPlan;
        this.price = newPrice;
        this.isEligibleForUpgrade = false;  // Reset eligibility
        return "Plan upgraded successfully to " + newPlan + ".";
    }

    /**
     * Reverts member to basic status
     * @param removalReason Explanation for reversion
     */
    public void revertRegularMember(String removalReason) {
        resetMember();
        this.isEligibleForUpgrade = false;
        this.plan = "basic";
        this.price = 6500;
        this.removalReason = removalReason;
        this.attendance = 0;
        System.out.println("Member " + getId() + " has been reverted to basic status.");
    }

    /**
     * Displays complete regular member information
     * Extends base class display with regular-specific details
     */
    @Override
    public void display() {
        super.display();
        System.out.println("Plan: " + plan);
        System.out.println("Price: " + price);
        System.out.println("Attendance Limit: " + attendanceLimit);
        if (!removalReason.isEmpty()) {
            System.out.println("Removal Reason: " + removalReason);
        }
    }
}