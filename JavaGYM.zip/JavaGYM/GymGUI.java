/* Import required libraries for GUI, events, and file operations */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.*;

/* Main class for Gym Management System GUI */
public class GymGUI {
    /* Stores all registered gym members (Regular and Premium) */
    private ArrayList<GymMember> membersList = new ArrayList<>();
    /* Reference to the currently active window */
    private JFrame currentFrame;
    /* Main container panel for UI components */
    private JPanel panel;
    /* Buttons for selecting member type */
    private JButton regularBtn, premiumBtn;

    /* Entry point of the application - creates and shows main menu */
    public static void main(String[] args) {
        /* Create new instance and display main menu */
        new GymGUI().createMainMenu();
    }

    /* Creates the initial member type selection screen */
    public void createMainMenu() {
        /* Configure main window properties */
        currentFrame = new JFrame("Select Member Type");
        currentFrame.setSize(500, 250);
        currentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        currentFrame.setLayout(null);
        
        /* Create main panel with light pink background */
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(0, 0, 500, 250);
        panel.setBackground(new Color(248, 235, 237));
        
        /* Add title label centered at top */
        JLabel titleLabel = new JLabel("Choose Member Type");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(150, 20, 200, 30);
        panel.add(titleLabel);

        /* Create Regular Member selection button */
        regularBtn = new JButton("Regular Member");
        regularBtn.setBounds(50, 80, 180, 40);
        /* Action listener switches to Regular Member interface */
        regularBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentFrame.dispose();
                createRegularMemberGUI();
            }
        });
        panel.add(regularBtn);

        /* Create Premium Member selection button */
        premiumBtn = new JButton("Premium Member");
        premiumBtn.setBounds(270, 80, 180, 40);
        /* Action listener switches to Premium Member interface */
        premiumBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentFrame.dispose();
                createPremiumMemberGUI();
            }
        });
        panel.add(premiumBtn);

        /* Add panel to frame and make visible */
        currentFrame.add(panel);
        currentFrame.setVisible(true);
    }

    /* Creates the Regular Member management interface */
    private void createRegularMemberGUI() {
        /* Configure window properties */
        currentFrame = new JFrame("Regular Member Management");
        currentFrame.setSize(900, 700);
        currentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        currentFrame.setLayout(null);

        /* Create main panel with same background color */
        panel = new JPanel();
        panel.setBounds(0, 0, 900, 700);
        panel.setLayout(null);
        panel.setBackground(new Color(248, 235, 237));
        
        /* Build all interface sections */
        createRegularMemberInformationSection(panel);
        createRegularMembershipActionsSection(panel);
        createRegularAttendanceManagementSection(panel);
        createRegularSystemActionsSection(panel);

        /* Display the window */
        currentFrame.add(panel);
        currentFrame.setVisible(true);
    }
    
    /* Creates the member information form section */
    private void createRegularMemberInformationSection(JPanel panel) {
        /* Section heading label */
        JLabel section1Heading = new JLabel("1. Member Information");
        section1Heading.setBounds(30, 0, 300, 25);
        section1Heading.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(section1Heading);
        
        /* Member ID input field */
        JLabel labelId = new JLabel("ID");
        labelId.setBounds(30, 30, 100, 25);
        panel.add(labelId);
        final JTextField idField = new JTextField();
        idField.setBounds(130, 30, 200, 25);
        panel.add(idField);

        /* Member name input field */
        JLabel labelName = new JLabel("Name");
        labelName.setBounds(470, 30, 100, 25);
        panel.add(labelName);
        final JTextField nameField = new JTextField();
        nameField.setBounds(550, 30, 200, 25);
        panel.add(nameField);
        
        /* Location input field */
        JLabel labelLocation = new JLabel("Location");
        labelLocation.setBounds(30, 70, 100, 25);
        panel.add(labelLocation);
        final JTextField locationField = new JTextField();
        locationField.setBounds(130, 70, 200, 25);
        panel.add(locationField);

        /* Phone number input field */
        JLabel labelPhone = new JLabel("Phone");
        labelPhone.setBounds(470, 70, 100, 25);
        panel.add(labelPhone);
        final JTextField phoneField = new JTextField();
        phoneField.setBounds(550, 70, 200, 25);
        panel.add(phoneField);
        
        /* Email input field (wider field) */
        JLabel labelEmail = new JLabel("Email");
        labelEmail.setBounds(30, 110, 100, 25);
        panel.add(labelEmail);
        final JTextField emailField = new JTextField();
        emailField.setBounds(130, 110, 620, 25);
        panel.add(emailField);

        /* Gender selection (radio buttons) */
        JLabel labelGender = new JLabel("Gender");
        labelGender.setBounds(470, 150, 100, 25);
        panel.add(labelGender);
        final JRadioButton femaleBtn = new JRadioButton("Female");
        femaleBtn.setBounds(550, 150, 80, 25);
        panel.add(femaleBtn);
        final JRadioButton maleBtn = new JRadioButton("Male");
        maleBtn.setBounds(640, 150, 80, 25);
        panel.add(maleBtn);
        final ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(femaleBtn);
        genderGroup.add(maleBtn);
        
        /* Date of Birth selection (three dropdowns) */
        JLabel labelDOB = new JLabel("DOB");
        labelDOB.setBounds(30, 150, 100, 25);
        panel.add(labelDOB);
        final JComboBox<String> dobDay = new JComboBox<>(new String[]{"Day", "01", "02", "03","04","05","06","07","08","09","10","11","12","13","14","15","16","17"});
        dobDay.setBounds(130, 150, 60, 25);
        panel.add(dobDay);
        final JComboBox<String> dobMonth = new JComboBox<>(new String[]{"Month", "January", "February", "March","April","May","June","July","August","September","November","December"});
        dobMonth.setBounds(190, 150, 80, 25);
        panel.add(dobMonth);
        final JComboBox<String> dobYear = new JComboBox<>(new String[]{"Year", "2000", "2001", "2002","2003","2004","2005","2006","2007","2008","2009","2010","2011"});
        dobYear.setBounds(270, 150, 80, 25);
        panel.add(dobYear);

        /* Referral source input field */
        JLabel labelReferral = new JLabel("Referral Source");
        labelReferral.setBounds(30, 190, 120, 25);
        panel.add(labelReferral);
        final JTextField referralField = new JTextField();
        referralField.setBounds(150, 190, 600, 25);
        panel.add(referralField);

        /* Membership start date selection */
        JLabel labelStartDate = new JLabel("Membership Start Date");
        labelStartDate.setBounds(30, 230, 180, 25);
        panel.add(labelStartDate);
        final JComboBox<String> startDay = new JComboBox<>(new String[]{"Day", "01", "02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17"});
        startDay.setBounds(230, 230, 60, 25);
        panel.add(startDay);
        final JComboBox<String> startMonth = new JComboBox<>(new String[]{"Month", "January", "February", "March","April","May","June","July","August","September","November","December"});
        startMonth.setBounds(290, 230, 80, 25);
        panel.add(startMonth);
        final JComboBox<String> startYear = new JComboBox<>(new String[]{"Year","2019","2020","2021","2022","2023","2024"});
        startYear.setBounds(370, 230, 80, 25);
        panel.add(startYear);

        /* Membership plan selection dropdown */
        final JComboBox<String> planCombo = new JComboBox<>(new String[]{"Basic", "Standard", "Deluxe"});
        planCombo.setBounds(80, 420, 100, 25);
        panel.add(planCombo);

        /* Add Member button with validation */
        JButton addRegularBtn = new JButton("Add Regular Member");
        addRegularBtn.setBounds(470, 230, 180, 30);
        addRegularBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Validate required fields */
                if(idField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "ID and Name are required!");
                    return;
                }
                
                /* Create new member if validation passes */
                try {
                    int id = Integer.parseInt(idField.getText().trim());
                    String name = nameField.getText().trim();
                    String location = locationField.getText().trim();
                    String phone = phoneField.getText().trim();
                    String email = emailField.getText().trim();
                    String dob = dobDay.getSelectedItem() + "-" + dobMonth.getSelectedItem() + "-" + dobYear.getSelectedItem();
                    String startDate = startDay.getSelectedItem() + "-" + startMonth.getSelectedItem() + "-" + startYear.getSelectedItem();
                    String gender = maleBtn.isSelected() ? "Male" : (femaleBtn.isSelected() ? "Female" : "");
                    String referral = referralField.getText().trim();
                    String plan = (String)planCombo.getSelectedItem();

                    /* Check for duplicate ID */
                    for(GymMember member : membersList) {
                        if(member.getId() == id) {
                            JOptionPane.showMessageDialog(currentFrame, "Member ID already exists!");
                            return;
                        }
                    }
                    
                    /* Create and add new regular member */
                    RegularMember member = new RegularMember(id, name, location, phone, email, gender, dob, startDate, referral);
                    member.upgradePlan(plan);
                    membersList.add(member);
                    JOptionPane.showMessageDialog(currentFrame, "Regular member added successfully!");
                    
                    /* Clear all form fields after successful addition */
                    idField.setText("");
                    nameField.setText("");
                    locationField.setText("");
                    phoneField.setText("");
                    emailField.setText("");
                    referralField.setText("");
                    genderGroup.clearSelection();
                    dobDay.setSelectedIndex(0);
                    dobMonth.setSelectedIndex(0);
                    dobYear.setSelectedIndex(0);
                    startDay.setSelectedIndex(0);
                    startMonth.setSelectedIndex(0);
                    startYear.setSelectedIndex(0);
                    planCombo.setSelectedIndex(0);
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(addRegularBtn);
    }

    /* Creates the membership actions section */
    private void createRegularMembershipActionsSection(JPanel panel) {
        /* Section heading */
        JLabel section2Heading = new JLabel("2. Membership Actions");
        section2Heading.setBounds(30, 270, 300, 25);
        section2Heading.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(section2Heading);

        /* ID input for membership actions */
        JLabel idLabel1 = new JLabel("ID:");
        idLabel1.setBounds(30, 300, 30, 25);
        panel.add(idLabel1);
        final JTextField idField1 = new JTextField();
        idField1.setBounds(60, 300, 70, 25);
        panel.add(idField1);

        /* Activate membership button */
        JButton activateBtn = new JButton("Activate");
        activateBtn.setBounds(140, 300, 120, 30);
        activateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField1.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Find and activate member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof RegularMember) {
                            member.activateMembership();
                            found = true;
                            break;
                        }
                    }
                    
                    if(found) {
                        JOptionPane.showMessageDialog(currentFrame, "Regular Member " + id + " activated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(currentFrame, "Regular Member ID " + id + " not found.");
                    }
                    idField1.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(activateBtn);

        /* Deactivate membership button */
        JButton deactivateBtn = new JButton("Deactivate");
        deactivateBtn.setBounds(280, 300, 120, 30);
        deactivateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField1.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Find and deactivate member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof RegularMember) {
                            member.deactivateMembership();
                            found = true;
                            break;
                        }
                    }
                    
                    if(found) {
                        JOptionPane.showMessageDialog(currentFrame, "Regular Member " + id + " deactivated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(currentFrame, "Regular Member ID " + id + " not found.");
                    }
                    idField1.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(deactivateBtn);

        /* Revert/remove member button */
        JButton revertRegularBtn = new JButton("Revert Regular Member");
        revertRegularBtn.setBounds(420, 300, 180, 30);
        JLabel reasonLabel = new JLabel("Reason:");
        reasonLabel.setBounds(610, 300, 60, 30);
        panel.add(reasonLabel);
        final JTextField reasonField = new JTextField();
        reasonField.setBounds(670, 300, 200, 30);
        panel.add(reasonField);
        revertRegularBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField1.getText().trim();
                String reason = reasonField.getText().trim();

                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                if(reason.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please provide a reason.");
                    return;
                }

                try {
                    int memberId = Integer.parseInt(id);
                    RegularMember memberToRemove = null;

                    /* Find member to remove */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof RegularMember) {
                            memberToRemove = (RegularMember)member;
                            break;
                        }
                    }

                    if(memberToRemove != null) {
                        membersList.remove(memberToRemove);
                        JOptionPane.showMessageDialog(currentFrame,
                            "Regular Member with ID " + memberId + " reverted successfully.\nReason: " + reason);
                        idField1.setText("");
                        reasonField.setText("");
                    } else {
                        JOptionPane.showMessageDialog(currentFrame, "No Regular Member found with ID " + memberId + ".");
                    }

                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a valid number!");
                }
            }
        });
        panel.add(revertRegularBtn);
    }

    /* Creates attendance management section */
    private void createRegularAttendanceManagementSection(JPanel panel) {
        /* Section heading */
        JLabel section3Heading = new JLabel("3. Attendance and Management");
        section3Heading.setBounds(30, 350, 300, 25);
        section3Heading.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(section3Heading);

        /* ID input for attendance */
        JLabel idLabel2 = new JLabel("ID:");
        idLabel2.setBounds(30, 380, 30, 25);
        panel.add(idLabel2);
        final JTextField idField2 = new JTextField();
        idField2.setBounds(60, 380, 70, 25);
        panel.add(idField2);

        /* Mark attendance button */
        JButton markAttendanceBtn = new JButton("Mark Attendance");
        markAttendanceBtn.setBounds(140, 380, 150, 30);
        markAttendanceBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField2.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Find member and mark attendance */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof RegularMember) {
                            if(member.isActiveStatus()) {
                                member.markAttendance();
                                found = true;
                                JOptionPane.showMessageDialog(currentFrame, "Attendance marked for Regular Member ID: " + id);
                            } else {
                                JOptionPane.showMessageDialog(currentFrame, "Cannot mark attendance - member is inactive.");
                                return;
                            }
                            break;
                        }
                    }
                    
                    if(!found) {
                        JOptionPane.showMessageDialog(currentFrame, "Regular Member ID " + id + " not found.");
                    }
                    idField2.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(markAttendanceBtn);
        
        /* Plan upgrade components */
        final JComboBox<String> planCombo = new JComboBox<>(new String[]{"Basic", "Standard", "Deluxe"});
        planCombo.setBounds(80, 420, 100, 25);
        panel.add(planCombo);
        JLabel planLabel = new JLabel("Plan");
        planLabel.setBounds(30, 420, 50, 25);
        panel.add(planLabel);
        JButton upgradePlanBtn = new JButton("Upgrade Plan");
        upgradePlanBtn.setBounds(300, 380, 150, 30);
        upgradePlanBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField2.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    String plan = (String)planCombo.getSelectedItem();
                    
                    /* Find member and upgrade plan */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof RegularMember) {
                            RegularMember regularMember = (RegularMember)member;
                            if(!regularMember.isActiveStatus()) {
                                JOptionPane.showMessageDialog(currentFrame, "Member must be active to upgrade plan.");
                                return;
                            }
                            
                            String result = regularMember.upgradePlan(plan);
                            found = true;
                            JOptionPane.showMessageDialog(currentFrame, result);
                            break;
                        }
                    }
                    
                    if(!found) {
                        JOptionPane.showMessageDialog(currentFrame, "Regular Member ID " + id + " not found.");
                    }
                    idField2.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(upgradePlanBtn);
    }

    /* Creates system actions section */
    private void createRegularSystemActionsSection(JPanel panel) {
        /* Section heading */
        JLabel section4Heading = new JLabel("4. System Actions");
        section4Heading.setBounds(30, 460, 300, 25);
        section4Heading.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(section4Heading);

        /* Display members button */
        JButton displayBtn = new JButton("Display");
        displayBtn.setBounds(30, 490, 120, 30);
        displayBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StringBuilder memberInfo = new StringBuilder();
                memberInfo.append("=== Regular Members ===\n");
                
                boolean hasRegularMembers = false;
                /* Build formatted member information */
                for(GymMember member : membersList) {
                    if(member instanceof RegularMember) {
                        hasRegularMembers = true;
                        RegularMember regMember = (RegularMember)member;
                        memberInfo.append("ID: ").append(member.getId()).append("\n");
                        memberInfo.append("Name: ").append(member.getName()).append("\n");
                        memberInfo.append("Location: ").append(member.getLocation()).append("\n");
                        memberInfo.append("Phone: ").append(member.getPhone()).append("\n");
                        memberInfo.append("Email: ").append(member.getEmail()).append("\n");
                        memberInfo.append("Gender: ").append(member.getGender()).append("\n");
                        memberInfo.append("DOB: ").append(member.getDOB()).append("\n");
                        memberInfo.append("Referral Source: ").append(regMember.getReferralSource()).append("\n");
                        memberInfo.append("Membership Start Date: ").append(member.getMembershipStartDate()).append("\n");
                        memberInfo.append("Plan: ").append(regMember.getPlan()).append("\n");
                        memberInfo.append("Price: $").append(regMember.getPrice()).append("\n");
                        memberInfo.append("Attendance: ").append(member.getAttendance()).append(" times\n");
                        memberInfo.append("Loyalty Points: ").append(member.getLoyaltyPoints()).append("\n");
                        memberInfo.append("Status: ").append(member.isActiveStatus() ? "Active" : "Inactive").append("\n");
                        memberInfo.append("----------------------\n\n");
                    }
                }
                
                if(!hasRegularMembers) {
                    memberInfo.append("No regular members found.\n");
                }
                
                /* Display in scrollable text area */
                JTextArea textArea = new JTextArea(memberInfo.toString());
                JScrollPane scrollPane = new JScrollPane(textArea);
                textArea.setEditable(false);
                JOptionPane.showMessageDialog(currentFrame, scrollPane, "Member Information", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        panel.add(displayBtn);

        /* Save to file button */
        JButton saveBtn = new JButton("Save To Files");
        saveBtn.setBounds(160, 490, 150, 30);
        saveBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveRegularMembersToFile();
            }
        });
        panel.add(saveBtn);

        /* Clear form button */
        JButton clearBtn = new JButton("Clear");
        clearBtn.setBounds(350, 490, 150, 30);
        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Clear all form fields */
                for(Component comp : panel.getComponents()) {
                    if(comp instanceof JTextField) {
                        ((JTextField)comp).setText("");
                    } else if(comp instanceof JComboBox) {
                        ((JComboBox<?>)comp).setSelectedIndex(0);
                    } else if(comp instanceof JRadioButton) {
                        ((JRadioButton)comp).setSelected(false);
                    }
                }
            }
        });
        panel.add(clearBtn);

        /* Read from file button */
        JButton readBtn = new JButton("Read from files");
        readBtn.setBounds(510, 490, 150, 30);
        readBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Create display window for file content */
                JFrame displayFrame = new JFrame("Member Details");
                displayFrame.setSize(900, 600);
                displayFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                displayFrame.setLayout(new BorderLayout());

                JTextArea textArea = new JTextArea();
                textArea.setEditable(false);
                textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                JScrollPane scrollPane = new JScrollPane(textArea);
                displayFrame.add(scrollPane, BorderLayout.CENTER);

                try (BufferedReader reader = new BufferedReader(new FileReader("MemberDetails.txt"))) {
                    StringBuilder formattedContent = new StringBuilder();
                    String line;
                    boolean isRegularSection = false;
                    boolean isPremiumSection = false;
                    
                    /* Read and format file content */
                    while((line = reader.readLine()) != null) {
                        if(line.contains("REGULAR MEMBER DETAILS")) {
                            isRegularSection = true;
                            isPremiumSection = false;
                            formattedContent.append(line).append("\n");
                            continue;
                        }
                        if(line.contains("PREMIUM MEMBER DETAILS")) {
                            isRegularSection = false;
                            isPremiumSection = true;
                            formattedContent.append("\n").append(line).append("\n");
                            continue;
                        }
                        if(line.contains("=====")) {
                            formattedContent.append(line).append("\n");
                            continue;
                        }
                        
                        /* Skip empty lines between sections */
                        if(line.trim().isEmpty()) continue;
                        
                        /* Format data lines to maintain alignment */
                        if(isRegularSection || isPremiumSection) {
                            formattedContent.append(line).append("\n");
                        }
                    }
                    
                    textArea.setText(formattedContent.toString());
                    displayFrame.setVisible(true);
                    
                } catch(IOException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "Error reading file: " + ex.getMessage());
                }
            }
        });
        panel.add(readBtn);

        /* Back to main menu button */
        JButton backBtn = new JButton("Back to Main");
        backBtn.setBounds(670, 490, 150, 30);
        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentFrame.dispose();
                createMainMenu();
            }
        });
        panel.add(backBtn);
    }
    
    /* Saves regular members to text file with formatted output */
    private void saveRegularMembersToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("MemberDetails.txt"))) {
            /* Write formatted header */
            writer.println("REGULAR MEMBER DETAILS");
            writer.println("====================================================================================================");
            writer.println(String.format("%-5s %-15s %-15s %-15s %-25s %-20s %-10s %-10s %-10s %-15s %-10s", 
                "ID", "Name", "Location", "Phone", "Email", "Start Date", "Plan", "Price", "Attendance", 
                "Loyalty Points", "Status"));
            writer.println("====================================================================================================");
            
            /* Write each member's details */
            for(GymMember member : membersList) {
                if(member instanceof RegularMember) {
                    RegularMember regMember = (RegularMember)member;
                    writer.println(String.format("%-5d %-15s %-15s %-15s %-25s %-20s %-10s %-10.2f %-10d %-15.2f %-10s",
                        member.getId(),
                        member.getName(),
                        member.getLocation(),
                        member.getPhone(),
                        member.getEmail(),
                        member.getMembershipStartDate(),
                        regMember.getPlan(),
                        regMember.getPrice(),
                        member.getAttendance(),
                        member.getLoyaltyPoints(),
                        member.isActiveStatus() ? "Active" : "Inactive"));
                }
            }
            
            JOptionPane.showMessageDialog(currentFrame, "Regular member details saved to MemberDetails.txt");
        } catch(IOException e) {
            JOptionPane.showMessageDialog(currentFrame, "Error saving to file: " + e.getMessage());
        }
    }

    /* Creates the Premium Member management interface */
    private void createPremiumMemberGUI() {
        /* Configure window properties */
        currentFrame = new JFrame("Premium Member Management");
        currentFrame.setSize(900, 700);
        currentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        currentFrame.setLayout(null);

        /* Create main panel */
        panel = new JPanel();
        panel.setBounds(0, 0, 900, 700);
        panel.setLayout(null);
        panel.setBackground(new Color(248, 235, 237));
        
        /* Add title label */
        JLabel titleLabel = new JLabel("Premium Member Management");
        titleLabel.setBounds(300, 10, 300, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(titleLabel);

        /* Member Information Section */
        JLabel idLabel = new JLabel("ID");
        idLabel.setBounds(30, 50, 100, 25);
        panel.add(idLabel);
        final JTextField idField = new JTextField();
        idField.setBounds(100, 50, 200, 25);
        panel.add(idField);

        JLabel nameLabel = new JLabel("Name");
        nameLabel.setBounds(350, 50, 100, 25);
        panel.add(nameLabel);
        final JTextField nameField = new JTextField();
        nameField.setBounds(420, 50, 200, 25);
        panel.add(nameField);

        JLabel locationLabel = new JLabel("Location");
        locationLabel.setBounds(30, 90, 100, 25);
        panel.add(locationLabel);
        final JTextField locationField = new JTextField();
        locationField.setBounds(100, 90, 200, 25);
        panel.add(locationField);

        JLabel phoneLabel = new JLabel("Phone");
        phoneLabel.setBounds(350, 90, 100, 25);
        panel.add(phoneLabel);
        final JTextField phoneField = new JTextField();
        phoneField.setBounds(420, 90, 200, 25);
        panel.add(phoneField);

        JLabel emailLabel = new JLabel("Email");
        emailLabel.setBounds(30, 130, 100, 25);
        panel.add(emailLabel);
        final JTextField emailField = new JTextField();
        emailField.setBounds(100, 130, 520, 25);
        panel.add(emailField);

        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setBounds(350, 170, 100, 25);
        panel.add(genderLabel);
        final JRadioButton femaleBtn = new JRadioButton("Female");
        femaleBtn.setBounds(420, 170, 80, 25);
        panel.add(femaleBtn);
        final JRadioButton maleBtn = new JRadioButton("Male");
        maleBtn.setBounds(500, 170, 80, 25);
        panel.add(maleBtn);
        final ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(femaleBtn);
        genderGroup.add(maleBtn);

        JLabel dobLabel = new JLabel("DOB");
        dobLabel.setBounds(30, 170, 100, 25);
        panel.add(dobLabel);
        final JComboBox<String> dobDay = new JComboBox<>(new String[]{"Day", "01", "02", "03","04","05","06","07","08","09","10","11","12","13","14","15","16","17"});
        dobDay.setBounds(100, 170, 60, 25);
        panel.add(dobDay);
        final JComboBox<String> dobMonth = new JComboBox<>(new String[]{"Month", "January", "February", "March","April","May","June","July","August","September","November","December"});
        dobMonth.setBounds(160, 170, 80, 25);
        panel.add(dobMonth);
        final JComboBox<String> dobYear = new JComboBox<>(new String[]{"Year", "2000", "2001", "2002","2003","2004","2005","2006","2007","2008","2009","2010","2011"});
        dobYear.setBounds(240, 170, 80, 25);
        panel.add(dobYear);

        JLabel trainerLabel = new JLabel("Personal Trainer");
        trainerLabel.setBounds(30, 210, 120, 25);
        panel.add(trainerLabel);
        final JComboBox<String> trainerCombo = new JComboBox<>(new String[]{"Select", "Trainer A", "Trainer B", "Trainer C"});
        trainerCombo.setBounds(150, 210, 200, 25);
        panel.add(trainerCombo);

        JLabel startDateLabel = new JLabel("Membership Start Date");
        startDateLabel.setBounds(30, 250, 180, 25);
        panel.add(startDateLabel);
        final JComboBox<String> startDay = new JComboBox<>(new String[]{"Day", "01", "02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17"});
        startDay.setBounds(210, 250, 60, 25);
        panel.add(startDay);
        final JComboBox<String> startMonth = new JComboBox<>(new String[]{"Month", "January", "February", "March","April","May","June","July","August","September","November","December"});
        startMonth.setBounds(270, 250, 80, 25);
        panel.add(startMonth);
        final JComboBox<String> startYear = new JComboBox<>(new String[]{"Year","2019","2020","2021","2022","2023","2024"});
        startYear.setBounds(350, 250, 80, 25);
        panel.add(startYear);

        JButton addPremiumBtn = new JButton("Add Premium Member");
        addPremiumBtn.setBounds(450, 250, 200, 30);
        addPremiumBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText().trim();
                String name = nameField.getText().trim();
                String location = locationField.getText().trim();
                String phone = phoneField.getText().trim();
                String email = emailField.getText().trim();
                String dob = dobDay.getSelectedItem() + "-" + dobMonth.getSelectedItem() + "-" + dobYear.getSelectedItem();
                String startDate = startDay.getSelectedItem() + "-" + startMonth.getSelectedItem() + "-" + startYear.getSelectedItem();
                String gender = maleBtn.isSelected() ? "Male" : (femaleBtn.isSelected() ? "Female" : "");
                String trainer = (String) trainerCombo.getSelectedItem();

                if(id.isEmpty() || name.isEmpty() || location.isEmpty() || phone.isEmpty() || email.isEmpty() || gender.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please fill all required fields.");
                    return;
                }

                try {
                    int memberId = Integer.parseInt(id);
                    
                    /* Check for duplicate ID */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId) {
                            JOptionPane.showMessageDialog(currentFrame, "Member ID already exists!");
                            return;
                        }
                    }
                    
                    /* Create and add new premium member */
                    PremiumMember member = new PremiumMember(memberId, name, location, phone, email, gender, dob, startDate, trainer);
                    membersList.add(member);
                    JOptionPane.showMessageDialog(currentFrame, "Premium member added successfully!");
                    
                    /* Clear form fields */
                    idField.setText("");
                    nameField.setText("");
                    locationField.setText("");
                    phoneField.setText("");
                    emailField.setText("");
                    dobDay.setSelectedIndex(0);
                    dobMonth.setSelectedIndex(0);
                    dobYear.setSelectedIndex(0);
                    startDay.setSelectedIndex(0);
                    startMonth.setSelectedIndex(0);
                    startYear.setSelectedIndex(0);
                    trainerCombo.setSelectedIndex(0);
                    genderGroup.clearSelection();
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "Invalid ID! Please enter a number.");
                }
            }
        });
        panel.add(addPremiumBtn);

        /* Membership Actions Section */
        JLabel membershipActionsLabel = new JLabel("Membership Actions");
        membershipActionsLabel.setBounds(30, 290, 200, 25);
        membershipActionsLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(membershipActionsLabel);

        JLabel activateIdLabel = new JLabel("ID:");
        activateIdLabel.setBounds(30, 320, 30, 25);
        panel.add(activateIdLabel);
        final JTextField activateIdField = new JTextField();
        activateIdField.setBounds(60, 320, 70, 25);
        panel.add(activateIdField);
        
        /* Activate membership button */
        JButton activateBtn = new JButton("Activate");
        activateBtn.setBounds(140, 320, 120, 30);
        activateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = activateIdField.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Find and activate premium member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof PremiumMember) {
                            member.activateMembership();
                            found = true;
                            break;
                        }
                    }
                    
                    if(found) {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member " + id + " activated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member ID " + id + " not found.");
                    }
                    activateIdField.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(activateBtn);

        /* Deactivate membership button */
        JButton deactivateBtn = new JButton("Deactivate");
        deactivateBtn.setBounds(270, 320, 120, 30);
        deactivateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = activateIdField.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Find and deactivate premium member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof PremiumMember) {
                            member.deactivateMembership();
                            found = true;
                            break;
                        }
                    }
                    
                    if(found) {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member " + id + " deactivated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member ID " + id + " not found.");
                    }
                    activateIdField.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(deactivateBtn);

        /* Revert/remove member button */
        JButton revertBtn = new JButton("Revert Premium Member");
        revertBtn.setBounds(400, 320, 200, 30);
        JLabel reasonLabel = new JLabel("Reason:");
        reasonLabel.setBounds(610, 320, 60, 30);
        panel.add(reasonLabel);
        final JTextField reasonField = new JTextField();
        reasonField.setBounds(670, 320, 200, 30);
        panel.add(reasonField);
        revertBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = activateIdField.getText().trim();
                String reason = reasonField.getText().trim();

                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                if(reason.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please provide a reason for reverting the member.");
                    return;
                }

                try {
                    int memberId = Integer.parseInt(id);
                    PremiumMember memberToRemove = null;

                    /* Find premium member to remove */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof PremiumMember) {
                            memberToRemove = (PremiumMember)member;
                            break;
                        }
                    }

                    if(memberToRemove != null) {
                        membersList.remove(memberToRemove);
                        JOptionPane.showMessageDialog(currentFrame,
                                "Premium Member with ID " + memberId +
                                        " reverted successfully.\nReason: " + reason);
                        activateIdField.setText("");
                        reasonField.setText("");
                    } else {
                        JOptionPane.showMessageDialog(currentFrame, "No Premium Member found with ID " + memberId + ".");
                    }

                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a valid number!");
                }
            }
        });
        panel.add(revertBtn);
    
        /* Attendance Section */
        JLabel attendanceLabel = new JLabel("Attendance");
        attendanceLabel.setBounds(30, 360, 200, 25);
        attendanceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(attendanceLabel);

        JLabel attendanceIdLabel = new JLabel("ID:");
        attendanceIdLabel.setBounds(30, 390, 30, 25);
        panel.add(attendanceIdLabel);
        final JTextField attendanceIdField = new JTextField();
        attendanceIdField.setBounds(60, 390, 70, 25);
        panel.add(attendanceIdField);

        /* Mark attendance button */
        JButton markAttendanceBtn = new JButton("Mark Attendance");
        markAttendanceBtn.setBounds(140, 390, 150, 30);
        markAttendanceBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = attendanceIdField.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Find and mark attendance for premium member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof PremiumMember) {
                            if(member.isActiveStatus()) {
                                member.markAttendance();
                                found = true;
                                JOptionPane.showMessageDialog(currentFrame, "Attendance marked for Premium Member ID: " + id);
                            } else {
                                JOptionPane.showMessageDialog(currentFrame, "Cannot mark attendance - member is inactive.");
                                return;
                            }
                            break;
                        }
                    }
                    
                    if(!found) {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member ID " + id + " not found.");
                    }
                    attendanceIdField.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(markAttendanceBtn);

        /* Payment Section */
        JLabel paymentLabel = new JLabel("Payment Section");
        paymentLabel.setBounds(30, 430, 150, 25);
        paymentLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(paymentLabel);

        JLabel paymentIdLabel = new JLabel("Member ID:");
        paymentIdLabel.setBounds(30, 460, 80, 25);
        panel.add(paymentIdLabel);
        final JTextField paymentIdField = new JTextField();
        paymentIdField.setBounds(120, 460, 70, 25);
        panel.add(paymentIdField);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(200, 460, 60, 25);
        panel.add(amountLabel);
        final JTextField amountField = new JTextField();
        amountField.setBounds(260, 460, 100, 25);
        panel.add(amountField);

        /* Pay due amount button */
        JButton payBtn = new JButton("Pay Due Amount");
        payBtn.setBounds(370, 460, 150, 30);
        payBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = paymentIdField.getText().trim();
                String amountStr = amountField.getText().trim();
                
                if(id.isEmpty() || amountStr.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter both ID and amount.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    double amount = Double.parseDouble(amountStr);
                    
                    if(amount <= 0) {
                        JOptionPane.showMessageDialog(currentFrame, "Amount must be positive.");
                        return;
                    }
                    
                    boolean found = false;
                    /* Process payment for premium member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof PremiumMember) {
                            PremiumMember premiumMember = (PremiumMember)member;
                            String result = premiumMember.payDueAmount(amount);
                            
                            /* Show payment result */
                            JOptionPane.showMessageDialog(currentFrame, 
                                String.format("Payment Result:\n%s\nCurrent Paid: $%.2f\nRemaining: $%.2f",
                                    result,
                                    premiumMember.getPaidAmount(),
                                    premiumMember.getPremiumCharge() - premiumMember.getPaidAmount()),
                                "Payment Status",
                                JOptionPane.INFORMATION_MESSAGE);
                            
                            found = true;
                            break;
                        }
                    }
                    
                    if(!found) {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member ID " + id + " not found.");
                    }
                    
                    paymentIdField.setText("");
                    amountField.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID and Amount must be numbers!");
                }
            }
        });
        panel.add(payBtn);

        /* Calculate discount button */
        JButton discountBtn = new JButton("Calculate Discount");
        discountBtn.setBounds(530, 460, 180, 30);
        discountBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = paymentIdField.getText().trim();
                if(id.isEmpty()) {
                    JOptionPane.showMessageDialog(currentFrame, "Please enter an ID.");
                    return;
                }
                
                try {
                    int memberId = Integer.parseInt(id);
                    boolean found = false;
                    
                    /* Calculate discount for premium member */
                    for(GymMember member : membersList) {
                        if(member.getId() == memberId && member instanceof PremiumMember) {
                            PremiumMember premiumMember = (PremiumMember)member;
                            String discountResult = premiumMember.calculateDiscount();
                            
                            JOptionPane.showMessageDialog(currentFrame,
                                String.format("Discount Status for ID %d:\n%s\nPaid Amount: $%.2f/%.2f",
                                    memberId,
                                    discountResult,
                                    premiumMember.getPaidAmount(),
                                    premiumMember.getPremiumCharge()),
                                "Discount Calculation",
                                JOptionPane.INFORMATION_MESSAGE);
                            
                            found = true;
                            break;
                        }
                    }
                    
                    if(!found) {
                        JOptionPane.showMessageDialog(currentFrame, "Premium Member ID " + id + " not found.");
                    }
                    
                    paymentIdField.setText("");
                    
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "ID must be a number!");
                }
            }
        });
        panel.add(discountBtn);

        /* System Actions Section */
        JLabel systemActionsLabel = new JLabel("System Actions");
        systemActionsLabel.setBounds(30, 500, 150, 25);
        systemActionsLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(systemActionsLabel);

        /* Display members button */
        JButton displayBtn = new JButton("Display");
        displayBtn.setBounds(30, 530, 120, 30);
        displayBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StringBuilder memberInfo = new StringBuilder();
                memberInfo.append("=== Premium Members ===\n");
                
                boolean hasPremiumMembers = false;
                /* Build formatted member information */
                for(GymMember member : membersList) {
                    if(member instanceof PremiumMember) {
                        hasPremiumMembers = true;
                        PremiumMember premMember = (PremiumMember)member;
                        memberInfo.append("ID: ").append(member.getId()).append("\n");
                        memberInfo.append("Name: ").append(member.getName()).append("\n");
                        memberInfo.append("Location: ").append(member.getLocation()).append("\n");
                        memberInfo.append("Phone: ").append(member.getPhone()).append("\n");
                        memberInfo.append("Email: ").append(member.getEmail()).append("\n");
                        memberInfo.append("Gender: ").append(member.getGender()).append("\n");
                        memberInfo.append("DOB: ").append(member.getDOB()).append("\n");
                        memberInfo.append("Personal Trainer: ").append(premMember.getPersonalTrainer()).append("\n");
                        memberInfo.append("Membership Start Date: ").append(member.getMembershipStartDate()).append("\n");
                        memberInfo.append("Premium Charge: $").append(premMember.getPremiumCharge()).append("\n");
                        memberInfo.append("Paid Amount: $").append(premMember.getPaidAmount()).append("\n");
                        memberInfo.append("Discount Amount: $").append(premMember.getDiscountAmount()).append("\n");
                        memberInfo.append("Net Paid: $").append(premMember.getPaidAmount() - premMember.getDiscountAmount()).append("\n");
                        memberInfo.append("Attendance: ").append(member.getAttendance()).append(" times\n");
                        memberInfo.append("Loyalty Points: ").append(member.getLoyaltyPoints()).append("\n");
                        memberInfo.append("Status: ").append(member.isActiveStatus() ? "Active" : "Inactive").append("\n");
                        memberInfo.append("----------------------\n\n");
                    }
                }
                
                if(!hasPremiumMembers) {
                    memberInfo.append("No premium members found.\n");
                }
                
                /* Display in scrollable text area */
                JTextArea textArea = new JTextArea(memberInfo.toString());
                JScrollPane scrollPane = new JScrollPane(textArea);
                textArea.setEditable(false);
                JOptionPane.showMessageDialog(currentFrame, scrollPane, "Member Information", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        panel.add(displayBtn);

        /* Clear form button */
        JButton clearBtn = new JButton("Clear");
        clearBtn.setBounds(160, 530, 120, 30);
        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Clear all form fields */
                for(Component comp : panel.getComponents()) {
                    if(comp instanceof JTextField) {
                        ((JTextField)comp).setText("");
                    } else if(comp instanceof JComboBox) {
                        ((JComboBox<?>)comp).setSelectedIndex(0);
                    } else if(comp instanceof JRadioButton) {
                        ((JRadioButton)comp).setSelected(false);
                    }
                }
            }
        });
        panel.add(clearBtn);

        /* Read from file button */
        JButton readBtn = new JButton("Read from files");
        readBtn.setBounds(290, 530, 150, 30);
        readBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Create display window for file content */
                JFrame displayFrame = new JFrame("Member Details");
                displayFrame.setSize(900, 600);
                displayFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                displayFrame.setLayout(new BorderLayout());

                JTextArea textArea = new JTextArea();
                textArea.setEditable(false);
                textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                JScrollPane scrollPane = new JScrollPane(textArea);
                displayFrame.add(scrollPane, BorderLayout.CENTER);

                try (BufferedReader reader = new BufferedReader(new FileReader("MemberDetails.txt"))) {
                    StringBuilder formattedContent = new StringBuilder();
                    String line;
                    boolean isRegularSection = false;
                    boolean isPremiumSection = false;
                    
                    /* Read and format file content */
                    while((line = reader.readLine()) != null) {
                        if(line.contains("PREMIUM MEMBER DETAILS")) {
                            isRegularSection = false;
                            isPremiumSection = true;
                            formattedContent.append("\n").append(line).append("\n");
                            continue;
                        }
                        if(line.contains("=====")) {
                            formattedContent.append(line).append("\n");
                            continue;
                        }
                        
                        /* Skip empty lines between sections */
                        if(line.trim().isEmpty()) continue;
                        
                        /* Format data lines to maintain alignment */
                        if(isRegularSection || isPremiumSection) {
                            formattedContent.append(line).append("\n");
                        }
                    }
                    
                    textArea.setText(formattedContent.toString());
                    displayFrame.setVisible(true);
                    
                } catch(IOException ex) {
                    JOptionPane.showMessageDialog(currentFrame, "Error reading file: " + ex.getMessage());
                }
            }
        });
        panel.add(readBtn);

        /* Save to file button */
        JButton saveBtn = new JButton("Save To Files");
        saveBtn.setBounds(450, 530, 150, 30);
        saveBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                savePremiumMembersToFile();
            }
        });
        panel.add(saveBtn);

        /* Back to main menu button */
        JButton backBtn = new JButton("Back to Main");
        backBtn.setBounds(610, 530, 150, 30);
        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentFrame.dispose();
                createMainMenu();
            }
        });
        panel.add(backBtn);

        /* Display the window */
        currentFrame.add(panel);
        currentFrame.setVisible(true);
    }
    
    /* Saves premium members to text file with formatted output */
    private void savePremiumMembersToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("MemberDetails.txt", true))) {
            /* Write formatted header */
            writer.println("\n\nPREMIUM MEMBER DETAILS");
            writer.println("===============================================================================================================");
            writer.println(String.format("%-5s %-15s %-15s %-15s %-25s %-20s %-15s %-10s %-15s %-15s %-10s", 
                "ID", "Name", "Location", "Phone", "Email", "Start Date", "Trainer", "Paid", 
                "Discount", "Net Paid", "Status"));
            writer.println("===============================================================================================================");
            
            /* Write each member's details */
            for(GymMember member : membersList) {
                if(member instanceof PremiumMember) {
                    PremiumMember premMember = (PremiumMember)member;
                    writer.println(String.format("%-5d %-15s %-15s %-15s %-25s %-20s %-15s %-10.2f %-15.2f %-15.2f %-10s",
                        member.getId(),
                        member.getName(),
                        member.getLocation(),
                        member.getPhone(),
                        member.getEmail(),
                        member.getMembershipStartDate(),
                        premMember.getPersonalTrainer(),
                        premMember.getPaidAmount(),
                        premMember.getDiscountAmount(),
                        premMember.getPaidAmount() - premMember.getDiscountAmount(),
                        member.isActiveStatus() ? "Active" : "Inactive"));
                }
            }
            
            JOptionPane.showMessageDialog(currentFrame, "Premium member details saved to MemberDetails.txt");
        } catch(IOException e) {
            JOptionPane.showMessageDialog(currentFrame, "Error saving to file: " + e.getMessage());
        }
    }
}