/**
 * PremiumMember is a subclass of GymMember, representing a premium gym member with additional features like a personal trainer.
 * It includes functionality to manage payments, calculate discounts, and revert to a regular member status.
 *
 * @author (Selina Singh)
 * @version (15 May, 2025)
 */
            
class PremiumMember extends GymMember {
    private final double premiumCharge = 50000;
    private String personalTrainer;
    private boolean isFullPayment;
    private double paidAmount;
    private double discountAmount;

    public PremiumMember(int id, String name, String location, String phone, String email, String gender,
    String DOB, String membershipStartDate, String personalTrainer) {
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.personalTrainer = personalTrainer;
        this.isFullPayment = false;
        this.paidAmount = 0;
        this.discountAmount = 0;
    }

    // Accessor methods
    public double getPremiumCharge() {
        return premiumCharge;
    }

    public String getPersonalTrainer() {
        return personalTrainer;
    }

    public boolean isFullPayment() {
        return isFullPayment;
    }

    public double getPaidAmount() {
        return paidAmount;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }
    
    public boolean revertMember(String reason) {
    // Any cleanup needed before removal
    return true;
    }

    // Method to pay due amount
    public String payDueAmount(double paidAmount) {
        if (isFullPayment) {
            return "Payment is already completed.";
        }
        if (this.paidAmount + paidAmount > premiumCharge) {
            return "Payment exceeds premium charge. Please pay the correct amount.";
        }

        // Update the paid amount
        this.paidAmount += paidAmount;

        // Check if payment is full
        if (this.paidAmount == premiumCharge) {
            isFullPayment = true;
        }

        // Calculate the remaining amount
        double remainingAmount = premiumCharge - this.paidAmount;
        return "Payment successfully done. Remaining amount to be paid: " + remainingAmount;
    }

    // Method to calculate the discount
    public String calculateDiscount() {
        if (isFullPayment) {
            discountAmount = 0.10 * premiumCharge; // 10% discount
            return "Discount calculated successfully. Discount amount: " + discountAmount;
        } else {
            discountAmount = 0;
            return "No discount available. Payment is not complete.";
        }
    }

    // Method to revert premium member
    public void revertPremiumMember() {
        super.resetMember();
        this.personalTrainer = "";
        this.isFullPayment = false;
        this.paidAmount = 0;
        this.discountAmount = 0;
    }

    // Override display method
    @Override
    public void display() {
        super.display();
        System.out.println("Personal Trainer: " + personalTrainer);
        System.out.println("Paid Amount: " + paidAmount);
        System.out.println("Is Full Payment: " + isFullPayment);

        double remainingAmount = premiumCharge - this.paidAmount;
        System.out.println("Remaining Amount to be Paid: " + remainingAmount);

        if (this.isFullPayment) {
            System.out.println("Discount Amount: " + discountAmount);
        }
    }

    // Override markAttendance method (if GymMember is not abstract)
    @Override
    public void markAttendance() {
        System.out.println("Marking attendance for PremiumMember.");
        
    }
}
