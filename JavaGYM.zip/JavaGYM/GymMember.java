/**
 * ABSTRACT CLASS: GymMember
 * 
 * This abstract class serves as the base class for all gym memberships.
 * It defines common properties and behaviors for both Regular and Premium members.
 * Contains core member information and basic membership management functionality.
 * @author Selina Singh
 * @version 16 May 2025
 */
public abstract class GymMember {
    /* Member Identification Information */
    protected int id;                // Unique identifier for each member
    protected String name;           // Full name of the member
    protected String location;       // Residential location/address
    protected String phone;          // Contact phone number
    protected String email;          // Contact email address
    protected String gender;         // Gender (Male/Female/Other)
    protected String DOB;            // Date of Birth (format: DD-MM-YYYY)
    
    /* Membership Information */
    protected String membershipStartDate;  // When membership was initiated
    protected int attendance;        // Count of gym visits/check-ins
    protected double loyaltyPoints;  // Accumulated loyalty rewards
    protected boolean activeStatus;  // Current membership status (active/inactive)

    /**
     * CONSTRUCTOR: GymMember
     * Initializes a new gym member with basic information
     * 
     * @param id Unique member identifier
     * @param name Full name of member
     * @param location Residential address
     * @param phone Contact number
     * @param email Email address
     * @param gender Gender identification
     * @param DOB Date of birth
     * @param membershipStartDate Membership commencement date
     */
    public GymMember(int id, String name, String location, String phone, String email, String gender,
                    String DOB, String membershipStartDate) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.phone = phone;
        this.email = email;
        this.gender = gender;
        this.DOB = DOB;
        this.membershipStartDate = membershipStartDate;
        this.attendance = 0;        // New members start with 0 attendance
        this.loyaltyPoints = 0;     // No loyalty points initially
        this.activeStatus = false;   // Memberships begin as inactive
    }

    /* GETTER METHODS - Provide access to member properties */
    
    /** @return The member's unique ID */
    public int getId() { return id; }
    
    /** @return The member's full name */
    public String getName() { return name; }
    
    /** @return The member's residential location */
    public String getLocation() { return location; }
    
    /** @return The member's phone number */
    public String getPhone() { return phone; }
    
    /** @return The member's email address */
    public String getEmail() { return email; }
    
    /** @return The member's gender */
    public String getGender() { return gender; }
    
    /** @return The member's date of birth */
    public String getDOB() { return DOB; }
    
    /** @return The membership start date */
    public String getMembershipStartDate() { return membershipStartDate; }
    
    /** @return Number of times member has attended */
    public int getAttendance() { return attendance; }
    
    /** @return Current loyalty points balance */
    public double getLoyaltyPoints() { return loyaltyPoints; }
    
    /** @return Current active status of membership */
    public boolean isActiveStatus() { return activeStatus; }

    /* SETTER METHODS - Modify member properties */
    
    /**
     * Sets the active status of the membership
     * @param activeStatus New status (true = active, false = inactive)
     */
    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    /* ABSTRACT METHODS - Must be implemented by subclasses */
    
    /**
     * Marks member attendance - implementation varies by member type
     * Regular members may earn loyalty points differently than Premium members
     */
    public abstract void markAttendance();

    /* CONCRETE METHODS - Common functionality for all members */
    
    /** 
     * Activates the membership 
     * Sets status to active and confirms activation
     */
    public void activateMembership() {
        this.activeStatus = true;
        System.out.println("The membership " + this.id + " is successfully activated.");
    }

    /**
     * Deactivates the membership
     * Checks current status before deactivation to prevent redundant operations
     */
    public void deactivateMembership() {
        if (this.activeStatus) {
            this.activeStatus = false;
            System.out.println("The membership " + this.id + " is successfully deactivated.");
        } else {
            System.out.println("The membership " + this.id + " is already deactivated.");
        }
    }

    /**
     * Resets member statistics
     * Clears attendance and loyalty points, sets status to inactive
     * Used when memberships are cancelled or expired
     */
    public void resetMember() {
        this.activeStatus = false;
        this.attendance = 0;
        this.loyaltyPoints = 0;
        System.out.println("The membership " + this.id + " has been reset.");
    }

    /* DISPLAY METHOD - Shows all member details */
    
    /**
     * Displays complete member information
     * Prints all properties to standard output in formatted manner
     */
    public void display() {
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
        System.out.println("Location: " + this.location);
        System.out.println("Phone: " + this.phone);
        System.out.println("Email: " + this.email);
        System.out.println("Gender: " + this.gender);
        System.out.println("DOB: " + this.DOB);
        System.out.println("Membership Start Date: " + this.membershipStartDate);
        System.out.println("Attendance: " + this.attendance);
        System.out.println("Loyalty Points: " + this.loyaltyPoints);
        System.out.println("Active Status: " + this.activeStatus);
    }
}